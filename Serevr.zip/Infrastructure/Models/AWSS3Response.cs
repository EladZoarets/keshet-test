﻿using Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Infrastructure.Models
{
    internal class AWSS3Response : ILoadFileResponse
    {
        #region Properties
        public string Message { get; }

        public int ErrorCode { get; }
        #endregion

        #region Constructors
        public AWSS3Response(string message, int errorCode)
        {
            Message = message;
            ErrorCode = errorCode;

        }
        #endregion
    }
}
