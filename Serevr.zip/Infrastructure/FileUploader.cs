﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Transfer;
using Domain.Interfaces;
using Domain.Models;
using Infrastructure.Models;
using System.Net;

namespace Infrastructure
{
    public class FileUploader : IStorageContext
    {
        public async Task<ILoadFileResponse> Upload(IFileStorage fileStorage)
        {
			try
			{
                if(fileStorage == null)
                    throw new ArgumentNullException(nameof(fileStorage));

                var uploadRequest = new TransferUtilityUploadRequest()
                {
                    InputStream = fileStorage.File,
                    Key = fileStorage.Key,
                    BucketName = fileStorage.Bucket,
                    CannedACL = S3CannedACL.NoACL,
                    PartSize = 5000
                };


                using var client = new AmazonS3Client("AKIA4FK7PY4NFYKREGMU", "XgEDfwleBNyVAD1baX7lDGT2ZPhZu/zl+ma3lCtF", RegionEndpoint.USEast1);
                var transferUtility = new TransferUtility(client);
               
                await transferUtility.UploadAsync(uploadRequest);

                return new AWSS3Response("successfully uploaded", 200);
            }
            catch (Exception ex)
			{
                return new AWSS3Response(ex.Message, 500);
      	    }
        }
    }
}