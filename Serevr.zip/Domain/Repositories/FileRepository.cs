﻿using Domain.Interfaces;
using Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Repositories
{
    public class FileRepository : IFileRepository
    {
        #region Members
        private readonly IStorageContext _context;
        #endregion

        #region Constructors
        public FileRepository(IStorageContext context)
        {
            _context = context;
        }
        #endregion

        public async Task<ILoadFileResponse> Upload(IFileStorage fileStorage)
        {
            if(fileStorage == null)
                throw new ArgumentNullException("The specified fileStorage is empty");


            return await _context.Upload(fileStorage);
        }
    }
}
