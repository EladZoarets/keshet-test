﻿using Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Models
{
    public class FileStorage : IFileStorage
    {
       
        #region Properties
        public MemoryStream File { get; }
        public string Bucket { get; }
        public string Key {get; }
        #endregion

        #region Constructors
        public FileStorage(MemoryStream file, string bucket, string key)
        {
            if(file == null)
                throw new ArgumentNullException("The specified file is empty.");

            if (string.IsNullOrWhiteSpace(bucket))
                throw new ArgumentNullException("The specified bucket is empty.");

            if (string.IsNullOrWhiteSpace(key))
                throw new ArgumentNullException("The specified key is empty.");

            
            File = file;
            Bucket = bucket;
            Key = key;
        }
        #endregion
    }
}
