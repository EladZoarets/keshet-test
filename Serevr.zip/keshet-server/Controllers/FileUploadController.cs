﻿using Domain.Interfaces;
using Domain.Models;
using Domain.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net.Mime;

namespace keshet_server.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class FileUploadController : ControllerBase
    {
        #region Members
        private readonly IFileRepository _fileRepository;
        #endregion

        public FileUploadController(IFileRepository fileRepository) 
        {
            _fileRepository = fileRepository;
        }

        [RequestFormLimits(MultipartBodyLengthLimit = 104857600)]
        [HttpPost(Name = "UploadFile")]
        public async Task<ActionResult> UploadFile(IFormFile file)
        {
            if (!file.ContentType.StartsWith("video", StringComparison.OrdinalIgnoreCase))
                return BadRequest("The specified file is not a media file.");

            using MemoryStream memoryStream = new MemoryStream();

            await file.CopyToAsync(memoryStream);
            var fileStorage = new FileStorage(memoryStream, "keshet-test", "topic-1/" + file.FileName);
            var results = await _fileRepository.Upload(fileStorage);

            return new ContentResult { Content = results.Message };
        }
    }
}
