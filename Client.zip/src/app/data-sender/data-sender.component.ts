import { Component } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-data-sender',
  templateUrl: 'data-sender.component.html'
})

export class DataSenderComponent {
  dataToSend!: string;
  selectedFile!: File | null | undefined;
  url:any;
  format:any;


  constructor(private dataService: DataService) { }
  onSelectFile(event: Event) {
    let files = (event.target as HTMLInputElement).files;
    this.selectedFile = files?.[0];

    if (this.selectedFile) {
        let reader = new FileReader();
        reader.readAsDataURL(this.selectedFile);
        
        if(this.selectedFile.type.indexOf('video') > -1){
          this.format = 'video';
        }
        reader.onload = (event) => {
          this.url = (<FileReader>event.target).result;
        }
    }
    
  }

  
  sendDataToServer() {
    if (this.selectedFile) {
        this.dataService.uploadFile(this.selectedFile ).subscribe(
        (response) => {
          console.log('Data sent successfully!', response);
        },
        (error) => {
          console.error('Error sending data:', error);
        }
      );
    }
  }
}
