import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { DataSenderComponent } from './data-sender/data-sender.component';
import { DataService } from './data.service';

@NgModule({
  declarations: [AppComponent, DataSenderComponent],
  imports: [BrowserModule, HttpClientModule,FormsModule],
  providers: [DataService],
  bootstrap: [AppComponent],
})
export class AppModule {}
