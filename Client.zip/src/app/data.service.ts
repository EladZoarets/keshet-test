import { HttpClient, HttpEventType, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';

@Injectable()
export class DataService {
  constructor(private http: HttpClient) {}
  
  uploadFile(file: File): Observable<number> {
    const formData = new FormData();
    formData.append('file', file);
  
    

    const headers = new HttpHeaders({
      'Content-Type': 'multipart/form-data',
      'accept': '*/*'
    });

    const body = { file: file };

    
    return this.http.post('https://localhost:7275/FileUpload', file, {
      headers: headers,
      observe: 'events'
    }).pipe(
      map(event => this.getUploadProgress(event))
    );
  }
  
  private getUploadProgress(event: any): number {
    switch (event.type) {
      case HttpEventType.UploadProgress:
        return Math.round(event.loaded / event.total * 100);
      case HttpEventType.Response:
        return 100;
      default:
        return 0;
    }
  }
}

